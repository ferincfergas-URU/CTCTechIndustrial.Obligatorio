﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CTCTechIndustrial.Domino.Enums
{
    public enum EstadoOrden
    {
        Pendiente,
        EnProceso,
        Finalizada

    }
}
