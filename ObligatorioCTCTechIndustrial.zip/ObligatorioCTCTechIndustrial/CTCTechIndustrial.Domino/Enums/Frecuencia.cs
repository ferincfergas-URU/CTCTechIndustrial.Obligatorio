﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CTCTechIndustrial.Domino.Enums
{
    public enum Frecuencia
    {
        Mensual,
        Trimestral,
        Semestral,
        Anual

    }
}
