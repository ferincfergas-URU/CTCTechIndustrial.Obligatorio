﻿using System;
using System.Collections.Generic;
using System.Text;
using CTCTechIndustrial.Domino.Enums;

namespace CTCTechIndustrial.Domino.Entidades
{
    public class Cliente
    {
        private string identifiacion;
        private TipoIdentificacion tipoIdentificacion;
        private string razonSocial;
        private string direccionPlanta;
        private string telefono;

        public string identificacion
        {
            get { return identifiacion; }
        }

        public TipoIdentificacion TipoIdentificacion
        {
            get { return tipoIdentificacion; }
        }
        public string RazonSocial
        {
            get { return razonSocial; }

        }

        public string DireccionPlanta
        {
            get { return direccionPlanta; }
        }
        public string Telefono
        {
            get { return telefono; }
        }

        public Cliente(
            string identificacion,
            TipoIdentificacion tipoIdentificacion,
            string razonSocial,
            string direccionPlanta,
            string telefono)
        {
            // verificaciones para ingreso de cliente : 

            if (string.IsNullOrWhiteSpace(identificacion))
                throw new Exception("Identificacion invalida");
            if (string.IsNullOrWhiteSpace(razonSocial))
                throw new Exception("Razon Social invalida");
            if (string.IsNullOrWhiteSpace(direccionPlanta))
                throw new Exception("Direccion de Planta invalida");
            if (string.IsNullOrWhiteSpace(telefono))
                throw new Exception("Telefono es invalido");

            // asignamos los valores a los atributos privado :

            this.identifiacion = identificacion.Trim();
            this.tipoIdentificacion = tipoIdentificacion;
            this.razonSocial = razonSocial;
            this.direccionPlanta = direccionPlanta;
            this.telefono = telefono;
        }
 
    }
}
