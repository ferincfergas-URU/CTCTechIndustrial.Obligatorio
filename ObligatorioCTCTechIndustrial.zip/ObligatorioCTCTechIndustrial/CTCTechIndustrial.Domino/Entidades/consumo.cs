﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CTCTechIndustrial.Domino.Entidades
{
    public class consumo
    {
        private insumo insumo { get; set; }
       private decimmal 
    }
}
