﻿using System;
using System.Collections.Generic;
using System.Text;
using CTCTechIndustrial.Domino.Enums;


namespace CTCTechIndustrial.Domino.Entidades
{
    public class Tecnicos
    {
        private int numeroLegajo { get; set; }
        private string documento { get; set; }
        private string nombre { get; set; }
        private string apellido { get; set; }
        private int telefono { get; set; }
        private string nombreUsuario { get; set; }
        private string passWord { get; set; }


    }
}
