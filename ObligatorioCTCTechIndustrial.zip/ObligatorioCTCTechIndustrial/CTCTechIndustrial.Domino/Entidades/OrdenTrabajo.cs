﻿using CTCTechIndustrial.Domino.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CTCTechIndustrial.Domino.Entidades
{
    public abstract class OrdenTrabajo
    {
        private int numero{ get; set; }
        private DateTime fechaSolicitud { get; set; }
        private DateTime fechaInicio { get; set; }
        private DateTime fechaFin {  get; set; }

        private EstadoOrden estadoOrden {  get; set; }
        private string direccion {  get; set; }
        private Cliente client { get; set; }
        private List<consumo> consumo =
            new List<consumo>();

    }
}
