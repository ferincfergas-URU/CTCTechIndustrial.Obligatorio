﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CTCTechIndustrial.Domino.Entidades
{
    public class insumo
    {
        private string nombre { get; set; }
        private decimal costoUnitario { get; set; }

        public insumo (string nombre, decimal costoUnitario)
        {   
        }
        puclic decimal calcularSubtotal()
        {
        }
    }
}
